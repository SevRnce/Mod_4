package Loops;
/**
 * Loop practice, analyze 5 inputs 
 */
/**
 * 
 */


import java.util.Scanner;

public class Loops { 
    public static void main(String[] args) {
    	
    	double inputI = 0;
    	double inputII = 0;
    	double inputIII = 0;
    	double inputIV = 0;
    	double inputV = 0;
    	double Total;
    	double Avg;
    	double Interest;
    	double currentMin = 0;
    	double currentMax = 0;
    	do {
    		System.out.print("Enter five #'s with spaces: ");
    	
    		try (Scanner input = new Scanner(System.in)) {
    			inputI = input.nextInt();
    			inputII = input.nextInt();
    			inputIII = input.nextInt();
    			inputIV = input.nextInt();
    			inputV = input.nextInt();
    		}
    		
        	
        	Total = inputI + inputII + inputIII + inputIV + inputV;
        	Avg = Total / 5;
        	Interest = Total * .2;
        	
        	for (int i = 0; i < 1; i++) {
        		if (inputI >= currentMax) {
        			currentMax = inputI;
        			if (inputII >= currentMax) {
            			currentMax = inputII;
            			if (inputIII >= currentMax) {
                			currentMax = inputIII;
                			if (inputIV >= currentMax) {
                    			currentMax = inputIV;
                    			if (inputV >= currentMax) {
                        			currentMax = inputV;	
                        		}
                    		}
                		}
            		}
        		}
        	}
        	for (int i = 0; i < 1; i++) {
        		currentMin = inputI;
        			if (inputII <= currentMin) {
            			currentMin = inputII;
            			if (inputIII <= currentMin) {
                			currentMin = inputIII;
                			if (inputIV <= currentMin) {
                    			currentMin = inputIV;
                    			if (inputV <= currentMin) {
                        			currentMin = inputV;	
                        		}
                    		}
                		}
            		}
        	}
/**            	else if (inputII > inputIII) {
            		if (inputII > inputIV) {
            			if (inputII > inputV) {
            				maxNum = inputII;
            			}
            			
            		}
            	}
            	else if (inputIII > inputIV) {
            		if (inputIII > inputV) {
            			maxNum = inputIII;        			
            		}
            	}
            	else if (inputIV > inputV) {
            		maxNum = inputIV;
            	}
            	else{
            		maxNum = inputV;
            	}
        	}
        	
        	        	
/**        	if (inputI > inputII) {
        		if (inputI > inputIII) {
        			if (inputI > inputIV) {
        				if (inputI > inputV) {
        					maxNum = inputI;
        				}
        			}
        			
        		}
        	}
        	else if (inputII > inputIII) {
        		if (inputII > inputIV) {
        			if (inputII > inputV) {
        				maxNum = inputII;
        			}
        			
        		}
        	}
        	else if (inputIII > inputIV) {
        		if (inputIII > inputV) {
        			maxNum = inputIII;        			
        		}
        	}
        	else if (inputIV > inputV) {
        		maxNum = inputIV;
        	}
        	else{
        		maxNum = inputV;
        	}
        	
        	if (inputI < inputII) {
        		if (inputI < inputIII) {
        			if (inputI < inputIV) {
        				if (inputI < inputV) {
        					minNum = inputI;
        				}
        			}
        			
        		}
        	}
        	else if (inputII < inputIII) {
        		if (inputII < inputIV) {
        			if (inputII < inputV) {
        				minNum = inputII;
        			}
        			
        		}
        	}
        	else if (inputIII < inputIV) {
        		if (inputIII < inputV) {
        			minNum = inputIII;        			
        		}
        	}
        	else if (inputIV < inputV) {
        		minNum = inputIV;
        		}
        	else{
        		minNum = inputV;
        	}
        	*/
        }
    	while (inputI == 0 || inputII == 0 || inputIII == 0 || inputIV == 0 || inputV == 0);
    	
    	System.out.println("Total: " + Total);
    	System.out.println("Average: " + Avg);
    	System.out.println("Interest: " + Interest);
    	System.out.println("Max: " + currentMax);
    	System.out.println("Min: " + currentMin);
    	}  	
}